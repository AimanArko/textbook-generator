import ollama
from utils.io import sanitize_filename
from core.gemma_prompting import build_prompt

USE_OLLAMA = False  # Set to True when running locally

def generate_chapter(topic):
    if USE_OLLAMA:
        import ollama
        response = ollama.chat(model="gemma", messages=[{"role": "user", "content": topic}])
        return response['message']['content']
    else:
        return f"### Chapter: {topic}\n\nThis is a placeholder summary for demo purposes."

def generate_chapter_with_ollama(topic: str) -> str:
    """
    Generate a textbook chapter using Ollama.
    """
    prompt = build_prompt(topic)
    response = ollama.chat(
        model="gemma:2b",
        messages=[{"role": "user", "content": prompt}]
    )
    return response["message"]["content"].strip()

def generate_chapter(topic: str) -> str:
    """
    Generate chapter for a topic using Ollama.
    """
    try:
        return generate_chapter_with_ollama(topic)
    except Exception as e:
        print(f"⚠️ Ollama failed for '{topic}': {e}")
        return f"# {topic}\n\n[Topic skipped due to generation error.]"