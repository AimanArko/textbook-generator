"""
Gemma Prompting Utilities
-------------------------
This module provides structured prompts for generating textbook chapters
using Gemma or other LLMs. Each prompt includes:

- Overview
- Key Concepts
- Examples
- Summary

Designed for academic clarity and consistency.
"""

def build_prompt(topic: str) -> str:
    """
    Constructs a structured prompt for generating a textbook chapter.

    Parameters:
        topic (str): The title of the chapter/topic.

    Returns:
        str: A formatted prompt string.
    """
    return f"""
You are an expert educator writing a textbook chapter on "{topic}".

Please generate the following sections:

## Overview
Briefly introduce the topic and its relevance.

## Key Concepts
List 3–5 key concepts related to "{topic}".

## Examples
Give 2 practical examples or case studies.

## Summary
Summarize the topic in 3–5 sentences.

Use clear, academic language suitable for undergraduate students.
"""

def build_validation_prompt(topic: str) -> str:
    """
    Constructs a prompt to validate whether a given topic is suitable
    for a textbook chapter.

    Parameters:
        topic (str): The candidate topic line.

    Returns:
        str: A formatted prompt string.
    """
    return f"""
You are reviewing textbook topics for an academic course.

Is the following line a valid, standalone topic suitable for a textbook chapter?

Topic: "{topic}"

Respond with "Yes" if it is a valid topic, or "No" if it is not.
"""