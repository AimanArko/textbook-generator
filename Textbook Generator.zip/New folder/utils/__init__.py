# utils/__init__.py

"""
Utility module init file. Enables importing helpers like:
from utils.book_image_reader import extract_text_from_images
"""
