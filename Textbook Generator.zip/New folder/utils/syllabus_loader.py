import os
import re
from PyPDF2 import PdfReader

def find_syllabus_file(directory: str = "data") -> str:
    """
    Searches for a syllabus file in the given directory.
    Supports .txt and .pdf formats.
    Returns the first match found.
    """
    patterns = [
        os.path.join(directory, "syllabus.txt"),
        os.path.join(directory, "syllabus.pdf")
    ]

    for path in patterns:
        if os.path.exists(path):
            return path

    raise FileNotFoundError("No syllabus file found in 'data/'. Expected 'syllabus.txt' or 'syllabus.pdf'.")

def load_syllabus(path: str) -> list:
    """
    Loads syllabus lines from a .pdf or .txt file.
    Returns a list of cleaned topic lines.
    """
    if path.endswith(".pdf"):
        reader = PdfReader(path)
        text = "\n".join(page.extract_text() or "" for page in reader.pages)
    elif path.endswith(".txt"):
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            text = f.read()
    else:
        raise ValueError("Unsupported file format. Use .pdf or .txt.")

    return extract_topic_lines(text)

def extract_topic_lines(syllabus_text: str) -> list:
    lines = syllabus_text.splitlines()
    return [line.strip() for line in lines if len(line.strip()) >= 10]