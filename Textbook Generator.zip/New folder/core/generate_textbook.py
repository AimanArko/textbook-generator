import os
from utils.io import load_chapter_titles, load_chapter, save_chapter
from utils.syllabus_loader import find_syllabus_file, load_syllabus
from core.generator import generate_chapter

def generate_textbook():
    chapters_dir = "output/chapters"
    final_textbook_path = "data/final_textbook.txt"

    # 📁 Ensure chapters directory exists
    if not os.path.exists(chapters_dir):
        os.makedirs(chapters_dir)
        print(f"📁 Created chapters directory: {chapters_dir}")

    # 📄 Load syllabus
    try:
        syllabus_path = find_syllabus_file("data")
        topics = load_syllabus(syllabus_path)
        print(f"📄 Loaded syllabus from: {syllabus_path}")
    except Exception as e:
        print(f"❌ Failed to load syllabus: {e}")
        return

    # 📋 Check extracted topics
    if not topics:
        print("⚠️ No topics extracted from syllabus.")
        return

    print(f"📋 Extracted {len(topics)} topics.")

    # 📝 Generate chapters
    for topic in topics:
        print(f"📝 Generating chapter for: {topic}")
        try:
            chapter_content = generate_chapter(topic)
            if chapter_content and chapter_content.strip():
                save_chapter(topic, chapter_content, chapters_dir)
            else:
                print(f"⚠️ Skipped empty chapter for: {topic}")
        except Exception as e:
            print(f"❌ Failed to generate chapter for '{topic}': {e}")

    # 📚 Compile final textbook
    chapter_titles = load_chapter_titles(chapters_dir)
    if not chapter_titles:
        print("⚠️ No chapter files found. Aborting compilation.")
        return

    full_textbook = ""
    for title in chapter_titles:
        chapter = load_chapter(title, chapters_dir)
        if chapter.strip():  # Skip empty chapter files
            full_textbook += f"\n\n# {title}\n\n{chapter}"

    with open(final_textbook_path, "w", encoding="utf-8") as f:
        f.write(full_textbook.strip())

    print(f"\n📚 Final textbook compiled and saved to {final_textbook_path}")

if __name__ == "__main__":
    generate_textbook()