import ollama
from utils.io import sanitize_filename
from core.gemma_prompting import build_prompt

def generate_chapter_with_ollama(topic: str) -> str:
    """
    Generate a textbook chapter using locally hosted Gemma via Ollama.
    """

    prompt = build_prompt(topic)

    # 🔧 Available model options:
    model_name = "gemma:2b"       # ✅ Active model (lightweight, fast)
    # model_name = "gemma:e2b"    # ⛔ Commented out — extended 2B model (longer context)
    # model_name = "gemma:7b"     # ⛔ Commented out — larger model for richer output

    response = ollama.chat(
        model=model_name,
        messages=[{"role": "user", "content": prompt}]
    )

    return response["message"]["content"].strip()

def generate_chapter(topic: str) -> str:
    """
    Generate chapter for a topic using local Ollama instance.
    Falls back gracefully if generation fails.
    """
    try:
        return generate_chapter_with_ollama(topic)
    except Exception as e:
        print(f"⚠️ Ollama failed for '{topic}': {e}")
        return f"# {topic}\n\n[Topic skipped due to generation error.]"