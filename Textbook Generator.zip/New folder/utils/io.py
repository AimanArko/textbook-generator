import os
import re

def sanitize_filename(name: str) -> str:
    """
    Removes invalid characters from a string to make it safe for use as a filename.
    """
    name = re.sub(r'[<>:"/\\|?*]', '', name)
    name = name.strip().rstrip('.')
    return name.replace(' ', '_')

def save_chapter(title: str, content: str, chapters_dir: str):
    """
    Saves chapter content to a sanitized filename inside the specified directory.
    """
    os.makedirs(chapters_dir, exist_ok=True)
    filename = sanitize_filename(title) + ".txt"
    path = os.path.join(chapters_dir, filename)
    with open(path, "w", encoding="utf-8") as f:
        f.write(f"# {title}\n\n{content.strip()}")

def load_chapter(title: str, chapters_dir: str) -> str:
    """
    Loads chapter content from a sanitized filename inside the specified directory.
    """
    filename = sanitize_filename(title) + ".txt"
    path = os.path.join(chapters_dir, filename)
    with open(path, "r", encoding="utf-8") as f:
        return f.read().strip()

def load_chapter_titles(chapters_dir: str) -> list:
    """
    Returns a list of chapter titles (filenames without .txt) from the specified directory.
    Filters out hidden or corrupted files.
    """
    return [
        f[:-4] for f in os.listdir(chapters_dir)
        if f.endswith(".txt") and not f.startswith("._")
    ]